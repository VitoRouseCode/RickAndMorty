const axios = require('axios')


const getCharDetail = (req,res)=>{
    const {id}=req.params;

    axios(`https://rickandmortyapi.com/api/character/${id}`)
    .then(response => response.data)
    .then(data=>{
        let char={id:data.id,
            image:data.image,
            name:data.name,
            gender:data.gender,
            species:data.species,
            origin:data.origin.name,
            status:data.status
                  
        }
        res.status(200).json(char)
    }
    
    )
}
module.exports=getCharDetail;
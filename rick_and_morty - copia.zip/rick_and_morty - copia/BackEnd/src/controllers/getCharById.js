 const axios = require('axios')


  const getCharById=((req,res)=>{
    res.setHeader('Access-Control-Allow-Origin', '*');
        const {id} = req.params
        axios(`https://rickandmortyapi.com/api/character/${id}`)
        .then(response => response.data)
        .then(data=>{
            let char={
                id:data.id,
                image:data.image,
                name:data.name,
                gender:data.gender,
                species:data.species
                      
            }
            res.status(200).json(char)
        })
       
           });
 
    
    

 




module.exports=getCharById;
/* /////const characters = require('./utils/data') */
/* const http =  require('http');
const getCharById = require('../controllers/getCharById')
const getCharDetail = require('../controllers/getCharDetail')
 */

/*///// const { url } = require('inspector'); */


/* http.createServer ((req,res)=>{
    res.setHeader('Access-Control-Allow-Origin', '*'); */
    /*//////// if(req.url.includes('rickandmorty/character')){
        let myurl=req.url.split('/').at(-1)
        let ch = characters.filter((e)=>e.id === Number(myurl))
        res.writeHead(200,{'Content-type':'application/json'}).end(JSON.stringify(ch[0]))
    } ////////*/

 /*    if(req.url.includes('onsearch')){
        let id = req.url.split('/').at(-1)
        getCharById(res,id)
    }

    if(req.url.includes('detail')){
        let id =req.url.split('/').at(-1)
        getCharDetail(res,id)
    }
}).listen(3001,'localhost')
 */
const express = require('express');

const server = express();
const PORT = 3001;
const Myrouter = require('../routes/index')

/*  server.use((req,res)=>{
    res.setHeader('Access-Control-Allow-Origin', '*');
})  */


server.use(express.json())


server.use('/',Myrouter);

server.listen(PORT,()=>{console.log('servidor escuhando en puerto:'+PORT)})
const {Router} = require('express');
const arreglo =require('../utils/favs')

const getCharById=require('../controllers/getCharById')
const getCharDetail=require('../controllers/getCharDetail')

const Myrouter = Router();

Myrouter.get('/onsearch/:id',getCharById)
Myrouter.get('/rickandmorty/detail/:id',getCharDetail)
Myrouter.post('/rickandmorty/fav',(req,res)=>{
    arreglo.push(req.body)
})
Myrouter.get('/rickandmorty/fav',(req,res)=>{
    res.json(arreglo)

})

    
   





module.exports=Myrouter;
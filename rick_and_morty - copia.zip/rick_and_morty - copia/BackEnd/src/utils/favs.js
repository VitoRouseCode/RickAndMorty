const {Router} = require('express');
const Myrouter = require('../routes');



const arreglo=[]


module.exports=arreglo;
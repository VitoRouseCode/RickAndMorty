import { useState,useEffect } from "react";
import {  Link, useParams } from "react-router-dom";
import axios from 'axios'

const  Detail =()=>{
  
    const [character,setCharacter]=useState([]) ;
    const {detailId} =useParams();

    console.log(detailId)

    useEffect(()=>{
       fetch(`http://localhost:3001/rickandmorty/detail/${detailId}`)
    .then((response) => response.json())
    .then((char) => {
      if (char.name) {
        setCharacter(char);
      } else {
        window.alert("No hay con ese ID");
      }
    })
    .catch((err) => {
      window.alert("No hay jovenes con ese ID");
    });
  return setCharacter({}); 
  
}, [detailId]);


    
    return(
        <div>

            
            <p>{character.name}</p>
            <p>{character.status}</p>
            <p>{character.species}</p>
            <p>{character.gender}</p>
            <p>{character.origin?.name}</p>
            <img src={character.image}/><hr></hr>
            
            <Link to='/home'><button>HOME</button></Link>
        
       
        
        </div>
        
    )
}

export default Detail;


const Abouts =()=>{
    return(
        <div>holaaaaaa abouts</div>
    )
}



export default Abouts;
import { useState } from "react";
import style from '../searchb/SearchBar.module.css'



export default function SearchBar(props) {
   const [characters,setCharacters]=useState('');
   const handleChange=(event)=>{
      setCharacters(event.target.value)

   }
   return (
      <div >
         <input className={style.campo} value={characters} onChange={handleChange} type='search' />
      <button className={style.boton} onClick={()=>props.onSearch(characters)}>Agregar</button>
      </div>
   );
}

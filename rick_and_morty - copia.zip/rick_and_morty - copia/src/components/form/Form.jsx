import { useState } from "react";
import Validations from "./Validations";
import style from '../form/Form.module.css';

const Form =(props)=>{
    const [userData, setUserData] =useState(
        { username: '',
         password: '' });

    const [errors,setErrors]=useState({
        username:'',
        password:''
    })

    const handleInputChange=(event)=>{
        
       
        if(event.target.name==='usuario'){
        setUserData({...userData,username:event.target.value}) 
        }
        if(event.target.name==='password'){
            setUserData({...userData,password:event.target.value})
        }
        setErrors(Validations({
            ...userData,
            [event.target.name]:event.target.value
        }))
    }
    const handleSubmit=(event)=>{
        event.preventDefault()
        props.Login(userData)
    }
   

    console.log(userData)
    console.log(errors)
         
    return(
        <div className={style.login}>
            <div className={style.cajaLogin}>
        <form onSubmit={handleSubmit} className={style.form}>
        <label className={style.label}>Usuario</label>
        <input className={style.input} type='text' name="usuario" value={userData.username} onChange={handleInputChange} ></input>
        {errors.username?<p className={style.error}>{errors.username}</p>:''}
        <label className={style.label}>Password</label>
        <input className={style.input} type='text' name="password" value={userData.password} onChange={handleInputChange}></input>
        {errors.password?<p className={style.error}>{errors.password}</p>:''}
        <button className={style.boton}>Login</button>
       

    </form>
        </div>
    </div>
    )
    
}
export default Form;



const Validations = (userData)=>{
    let errors={}
    if(!/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(userData.username)){
        
            errors.username="el nombre de usuario no es valido, debe ser un email."
        
    if(userData.username===''){
        
            errors.username="el campo debe ser rellenado"
        
    if(userData.username.length>30){
        
            errors.username="el nombre no puede tener mas de 30 caracteres"
       
    }
}
    
} 
if(!userData.password.match(/^(?=\w*\d)(?=\w*[A-Z])(?=\w*[a-z])\S{8,16}$/)){
        
    errors.password="la contraseña debe contener un digito, y una mayuscula"

}
return errors;
}

export default Validations;
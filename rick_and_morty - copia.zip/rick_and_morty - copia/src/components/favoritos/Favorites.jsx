import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import * as action from '../../redux/action'


const Favorites =()=>{
    const myFavorite = useSelector(state=>state.myFavorites)
    const dispatch = useDispatch();

        
    const handleSelect=(event)=>{
            dispatch(action.orderCards(event.target.value))
        }
    const handlefilter=(event)=>{
            dispatch(action.filterCards(event.target.value))
        }
    return(
        
        <div>
            <div>
                <select onChange={handleSelect} name="filter" id="">
                <option value="order" disabled="disabled">Order By</option>
                <option value="Ascendente">Ascendente</option>
                <option value="Descendente">Descendente</option>
                </select>
                <select onChange={handlefilter} name="" id="">
                <option value="filter" disabled="disabled">Filter By</option>
                    <option  value="Male">Male</option>
                    <option  value="Female">Female</option>
                    <option  value="Genderless">Genderless</option>
                    <option  value="unknown">unknown</option>
                </select>
                <div>
                    <button onClick={()=>{dispatch(action.reseteo())}}>RESET</button>
                </div>
            </div>
        {myFavorite.map((e)=><div>
        <div>{e.name}</div>
        <div>{e.gender}</div>
        <div>{e.species}</div>
        <img src={e.image}/>
        </div>
        )}
        </div>
    )
}

export default Favorites;
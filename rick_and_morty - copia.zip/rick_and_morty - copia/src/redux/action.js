import axios from 'axios';
export const AGREGAR_PERSONAJE='AGREGAR_PERSONAJE';
export const ELIMINAR_PERSONAJE='ELIMINAR_PERSONAJE';
export const FILTER='FILTER';
export const ORDER='ORDER';
export const RESET='RESET';


export const adicionaPersonaje =(character)=>{
    
    return function (dispatch){
        console.log()
        axios.post(`http://localhost:3001/rickandmorty/fav`,character)
        .then((response) => response.data)
        .then((data)=>{
            
            dispatch({
                type:AGREGAR_PERSONAJE,payload:data
                
            })
        })
    }
}

export const eliminaPersonaje =(id)=>{
    return{
        type:ELIMINAR_PERSONAJE,payload:id
    }
}

export const filterCards=(gender)=>{
    return{
        type:FILTER,payload:gender
    }
}

export const orderCards=(id)=>{
    return{
        type:ORDER,payload:id
    }

}

export const reseteo=()=>{
    return{
        type:RESET
    }
}
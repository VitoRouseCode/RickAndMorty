
import { AGREGAR_PERSONAJE,ELIMINAR_PERSONAJE, FILTER, ORDER,RESET } from './action';

const initialState ={
    myFavorites:[],
    myFavoritesOrigin:[],
    
}


const reducer =(state=initialState,action)=>{
    switch(action.type){
        
        case AGREGAR_PERSONAJE:
            
            return{
                ...state,
                myFavorites:[...state.myFavoritesOrigin,action.payload],
                myFavoritesOrigin:[...state.myFavoritesOrigin,action.payload]
            }
            
        case ELIMINAR_PERSONAJE:
            const filtered= state.myFavorites.filter(c=>c.id !== action.payload)
            return{
                ...state,
                myFavorites: filtered,
                myFavoritesOrigin:filtered
                
            }

        case FILTER:
                
                const filtrados = state.myFavorites.filter((e)=>e.gender === action.payload)
                return{
                    ...state,
                    myFavorites:filtrados
                }
        case ORDER:
                const ordercopy =[...state.myFavoritesOrigin]
        const order = ordercopy.sort((a,b)=>{
            if(a.id>b.id){
                return 'Ascendente'=== action.payload?1:-1;
            }
            if(a.id<b.id){
                return 'Descendente' === action.payload?1:-1;
            }
            return 0;
        })
            return{
                ...state,
                myFavorites:order
                   
            }
            case RESET:
            
            return{
                ...state,
                myFavorites: [...state.myFavoritesOrigin]
                
            }
            
        
        
            
        default: 
        return{
            ...state
        } 
    }
    
}

export default reducer;
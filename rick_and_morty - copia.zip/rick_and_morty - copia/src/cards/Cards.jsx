import Card from '../card/Card';
import style from '../cards/Cards.module.css';

export default function Cards(props) {
   const { characters } = props;
  
   return( 
   <div className={style.home}>
   <div className={style.divPrincipal}>
      
      {characters?.map((e) => {return  <Card 
      
         key={e.id}
         name={e.name}
         species={e.species}
         gender={e.gender}
         image={e.image}
         onClose={() =>props.onClose(e.id)}
         id={e.id}
         
         />})}
   </div>
   </div>);
}

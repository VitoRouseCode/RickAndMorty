import { useState,useEffect } from 'react'

import Cards from './cards/Cards.jsx'
import SearchBar from './components/searchb/SearchBar.jsx'
import Nav from './nav/Nav'
import {  Route,Routes,useLocation,useNavigate } from 'react-router-dom';
import About from './components/about/About';
import Detail from './components/details/Detail';
import Card from './card/Card';
import Form from './components/form/Form'
import Favorites from './components/favoritos/Favorites'




function App () {
  const [characters,setCharacters]=useState([
    ])
  const [acces,setAcces]=useState(false)
  const username='victor@gmail.com'
  const password='Musika4321'
    const navigate = useNavigate();
  
    const Login=(userData)=>{

    if(userData.username===username && userData.password===password){
        setAcces(true)
        navigate('/home')

    }
  }
  useEffect(() => {
    !acces && navigate('/');
 }, [acces]);
     
  const onClose = (id)=>{
    setCharacters(
      characters.filter((character)=>character.id !== id ))
  }
  
    function onSearch(character) {
      console.log(character)
      fetch(`http://localhost:3001/onsearch/${character}`)
         .then((response) => response.json())
         .then((data) => {
          
            if (data.name) {
               setCharacters((oldChars) => [...oldChars, data]);
            } else {
               window.alert('No hay personajes con ese ID');
            }
         });
   }
   const location = useLocation();
  return (
    <div >
      {location.pathname === '/'?<Form Login={Login}/>:<Nav  onSearch={onSearch}/> }
      
    
    <Routes>
       <Route path='/about' element={<About/>}></Route>
       <Route path='/favorites' element={<Favorites/>}></Route>
       <Route  path='/home' element={<Cards characters={characters} onClose={onClose}/>}></Route>
       <Route path='/detail/:detailId' element={<Detail/>}></Route>
        
    </Routes>
    
    </div>
    )
}

export default App

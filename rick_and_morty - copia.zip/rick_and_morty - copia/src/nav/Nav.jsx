import style from '../nav/Nav.module.css';
import SearchBar from '../components/searchb/SearchBar';
import { Link } from 'react-router-dom';
import Cards from '../cards/Cards';

const Nav=({onSearch})=>{
return(
    
    <div className={style.Div_principal}>
       
    <Link className={style.links} to='/'>Logout</Link>
    <Link className={style.links} to="/about">About</Link>
    <Link className={style.links} to="/home">Home</Link>
    <Link className={style.links} to="/form">form</Link>
    <Link className={style.links} to='/favorites'>Favorites</Link>
    <SearchBar  onSearch={onSearch}/>
    
    
    </div>
    
    
)
}
export default Nav;
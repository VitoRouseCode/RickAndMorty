import { Link } from 'react-router-dom';
import style from '../card/tarjeta.module.css'
import { useDispatch,useSelector } from 'react-redux';

import * as action from '../redux/action';
import { useState } from 'react';
import { useEffect } from 'react';


export default function Card({key,name,species,gender,image,onClose,id}) {
   const [isFav,setIsfav]=useState(false)

   const dispatch = useDispatch();
   const favorites=useSelector(state=>state.myFavorites)

   const handleFavorite=()=>{
      if(isFav){
         setIsfav(false)
         dispatch(action.eliminaPersonaje(id))
      }
      if(!isFav){
         setIsfav(true)
         dispatch(action.adicionaPersonaje({name,species,gender,image,onClose,id}))
      }
   }
   useEffect(() => {
      favorites.forEach((fav) => {
         if (fav.id === id) {
            setIsfav(true);
         }
      });
   }, [favorites]);

   

   

   
   
   console.log(isFav)
   return (
      
      <div className={style.tarjeta}>
         <div className={style.btnfav}>
         {
            isFav ? (
            <button className={style.buttonscard}  onClick={handleFavorite}>❤️</button>
            ) : (
            <button className={style.buttonscard} onClick={handleFavorite}>🤍</button>
            )
         }
         <button className={style.cerrar}   onClick={onClose}>X</button>
         </div>

         <div className={style.areaboton}>
         
         </div>
         <div className={style.image} >
         <img className={style.imain} src={image} alt="" /> 
         </div>
         <div className={style.cajanombre}>
         <Link className={style.lin} to={`/detail/${id}`} ><h2 className={style.nombre}>{name}</h2></Link>
         </div>
         <h2 className={style.species}>{species}</h2><hr></hr>
         <h2 className={style.gender}>{gender}</h2>
         
         
      </div>
   );
}
